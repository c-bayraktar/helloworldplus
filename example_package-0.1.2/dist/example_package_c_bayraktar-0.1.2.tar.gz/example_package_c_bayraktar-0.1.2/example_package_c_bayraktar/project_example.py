def target(obj):
  if obj == 'exoplanets':
    print('Hello World!')
  elif obj == 'exomoons':
    print('Hello Moon!')
  elif obj == 'solar':
    print('Hello Star!')
  else:
    print('There was either a typo or this research interest is not included...yet!')