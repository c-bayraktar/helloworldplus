# helloworld+
helloworld+ is a simple mock package to obtain the classic phrase 'Hello World!' and its variation(s) depending on your research interest. As of the moment there are only three research interests to choose from: exoplanets, exomoons, and solar. 


Install and import the package:
```ruby
pip install -i https://test.pypi.org/simple/ example-package-c-bayraktar --upgrade
from example_package_c_bayraktar import project_example as pe
```
Enter your research interest (see above) in the function to get the result, e.g.
```ruby
pe.target('exoplanets')
```

